module.exports = {
  development: {
    username: "postgres",
    password: "newcore",
    database: "ameer_db",
    host: "127.0.0.1",
    dialect: "postgres"
  }
}
